window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 40 || document.documentElement.scrollTop > 40) {
    document.getElementById("header").style.fontSize = ".5em";
  } else {
    document.getElementById("header").style.fontSize = "1em";
  }
}